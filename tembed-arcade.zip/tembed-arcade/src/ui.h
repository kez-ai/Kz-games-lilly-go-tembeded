#pragma once
#include <Arduino.h>
#include "board.h"

typedef lgfx::LGFX_Sprite Canvas;

constexpr int SCREEN_W = 320;
constexpr int SCREEN_H = 170;
constexpr float PI_F = 3.14159265f;

constexpr uint16_t mk565(uint8_t r, uint8_t g, uint8_t b) {
  return (uint16_t)(((r & 0xF8) << 8) | ((g & 0xFC) << 3) | (b >> 3));
}

namespace pal {
constexpr uint16_t BG     = mk565(8, 10, 20);
constexpr uint16_t PANEL  = mk565(16, 20, 36);
constexpr uint16_t WHITE  = mk565(255, 255, 255);
constexpr uint16_t DIM    = mk565(120, 130, 150);
constexpr uint16_t RED    = mk565(255, 70, 80);
constexpr uint16_t GREEN  = mk565(60, 230, 120);
constexpr uint16_t BLUE   = mk565(70, 140, 255);
constexpr uint16_t YELLOW = mk565(255, 210, 60);
constexpr uint16_t ORANGE = mk565(255, 140, 40);
constexpr uint16_t PURPLE = mk565(180, 100, 255);
constexpr uint16_t CYAN   = mk565(60, 220, 240);
constexpr uint16_t PINK   = mk565(255, 100, 190);
}  // namespace pal

inline float clampf(float v, float lo, float hi) { return v < lo ? lo : (v > hi ? hi : v); }
inline int clampi(int v, int lo, int hi) { return v < lo ? lo : (v > hi ? hi : v); }
inline float minf(float a, float b) { return a < b ? a : b; }
inline float maxf(float a, float b) { return a > b ? a : b; }
inline float frand(float a, float b) { return a + (b - a) * (random(0, 10001) / 10000.0f); }
inline int wrapi(int v, int n) { return ((v % n) + n) % n; }

inline void textCentered(Canvas& g, const char* s, int cx, int y, float size, uint16_t color) {
  g.setTextSize(size);
  g.setTextColor(color);
  int w = g.textWidth(s);
  g.drawString(s, cx - w / 2, y);
}

inline void textRight(Canvas& g, const char* s, int rx, int y, float size, uint16_t color) {
  g.setTextSize(size);
  g.setTextColor(color);
  int w = g.textWidth(s);
  g.drawString(s, rx - w, y);
}

inline void textLeft(Canvas& g, const char* s, int x, int y, float size, uint16_t color) {
  g.setTextSize(size);
  g.setTextColor(color);
  g.drawString(s, x, y);
}
