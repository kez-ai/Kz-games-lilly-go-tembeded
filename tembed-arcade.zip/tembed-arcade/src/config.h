#pragma once
// Header-only project: every header is included once, from main.cpp.
#include <Arduino.h>

struct AppConfig {
  bool flip = false;     // screen rotated 180 degrees
  bool reverse = false;  // knob direction reversed
  uint8_t led = 2;       // 0=off 1=low 2=medium 3=high
};
static AppConfig cfg;

void applyConfig();      // defined in main.cpp: applies + saves settings
void resetAllScores();   // defined in main.cpp
