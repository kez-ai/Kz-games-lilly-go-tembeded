#pragma once
#include <Arduino.h>
#include "board.h"
#include "config.h"

// ---- Rotary encoder: interrupt driven, full-step Gray-code decoder ----
// (one detent = one step, no missed turns even while the screen is redrawing)
constexpr uint8_t R_START = 0x0, R_CW_FINAL = 0x1, R_CW_BEGIN = 0x2, R_CW_NEXT = 0x3,
                  R_CCW_BEGIN = 0x4, R_CCW_FINAL = 0x5, R_CCW_NEXT = 0x6;
constexpr uint8_t DIR_CW = 0x10, DIR_CCW = 0x20;

static const uint8_t kEncTable[7][4] = {
    {R_START, R_CW_BEGIN, R_CCW_BEGIN, R_START},
    {R_CW_NEXT, R_START, R_CW_FINAL, (uint8_t)(R_START | DIR_CW)},
    {R_CW_NEXT, R_CW_BEGIN, R_START, R_START},
    {R_CW_NEXT, R_CW_BEGIN, R_CW_FINAL, R_START},
    {R_CCW_NEXT, R_START, R_CCW_BEGIN, R_START},
    {R_CCW_NEXT, R_CCW_FINAL, R_START, (uint8_t)(R_START | DIR_CCW)},
    {R_CCW_NEXT, R_CCW_FINAL, R_CCW_BEGIN, R_START},
};

static volatile uint8_t g_encState = R_START;
static volatile int32_t g_encSteps = 0;

static void IRAM_ATTR encoderISR() {
  uint8_t s = (uint8_t)((digitalRead(pins::ENC_B) << 1) | digitalRead(pins::ENC_A));
  g_encState = kEncTable[g_encState & 0x0f][s];
  uint8_t dir = g_encState & 0x30;
  if (dir == DIR_CW) g_encSteps = g_encSteps + 1;
  else if (dir == DIR_CCW) g_encSteps = g_encSteps - 1;
}

struct InputState {
  int delta = 0;           // knob detents since last frame (+ = clockwise)
  bool pressed = false;    // short press, fires on release
  bool longPress = false;  // held >= 600 ms, fires once
  bool down = false;       // button currently held
};

class Input {
 public:
  void begin() {
    pinMode(pins::ENC_A, INPUT_PULLUP);
    pinMode(pins::ENC_B, INPUT_PULLUP);
    pinMode(pins::ENC_KEY, INPUT_PULLUP);
    attachInterrupt(digitalPinToInterrupt(pins::ENC_A), encoderISR, CHANGE);
    attachInterrupt(digitalPinToInterrupt(pins::ENC_B), encoderISR, CHANGE);
  }

  void poll() {
    noInterrupts();
    int32_t n = g_encSteps;
    g_encSteps = 0;
    interrupts();
    s_.delta = cfg.reverse ? -(int)n : (int)n;

    uint32_t now = millis();
    bool raw = digitalRead(pins::ENC_KEY) == LOW;
    s_.pressed = false;
    s_.longPress = false;
    if (raw && !down_ && now - lastChange_ > 25) {
      down_ = true;
      downAt_ = now;
      longFired_ = false;
      lastChange_ = now;
    } else if (!raw && down_ && now - lastChange_ > 25) {
      down_ = false;
      lastChange_ = now;
      if (!longFired_) s_.pressed = true;
    }
    if (down_ && !longFired_ && now - downAt_ >= 600) {
      longFired_ = true;
      s_.longPress = true;
    }
    s_.down = down_;
  }

  const InputState& state() const { return s_; }

 private:
  InputState s_;
  bool down_ = false;
  bool longFired_ = false;
  uint32_t downAt_ = 0;
  uint32_t lastChange_ = 0;
};
