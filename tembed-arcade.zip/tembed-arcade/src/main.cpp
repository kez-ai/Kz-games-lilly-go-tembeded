// T-Embed Arcade for the LilyGO T-Embed CC1101
// Turn the knob to browse, press to play, hold the knob to go back.
#include <Arduino.h>
#include <Preferences.h>
#include <esp_system.h>

#include "board.h"
#include "config.h"
#include "ui.h"
#include "input.h"
#include "leds.h"
#include "game.h"
#include "games/breakout.h"
#include "games/pong.h"
#include "games/snake.h"
#include "games/dodge.h"
#include "games/simon.h"
#include "games/settings.h"

static LGFX lcd;
static Canvas canvas(&lcd);
static Input inputDev;
static Preferences prefs;

static BreakoutGame breakout;
static PongGame pong;
static SnakeGame snake;
static DodgeGame dodge;
static SimonGame simon;
static SettingsScreen settings;

static Game* entries[] = {&breakout, &pong, &snake, &dodge, &simon, &settings};
static const int N = sizeof(entries) / sizeof(entries[0]);

static Game* active = nullptr;
static int activeIdx = -1;
static int curSel = 0, prevSel = 0;
static float slide = 0;
static uint32_t lastMicros = 0;

// ---------- settings / scores ----------
void applyConfig() {
  lcd.setRotation(cfg.flip ? 3 : 1);
  leds.setLevel(cfg.led);
  prefs.putBool("flip", cfg.flip);
  prefs.putBool("rev", cfg.reverse);
  prefs.putUChar("led", cfg.led);
}

static void saveBest(int idx) {
  char key[8];
  snprintf(key, sizeof key, "b%d", idx);
  prefs.putUInt(key, entries[idx]->best);
  entries[idx]->bestChanged = false;
}

void resetAllScores() {
  for (int i = 0; i < N; i++) {
    entries[i]->best = 0;
    saveBest(i);
  }
}

// ---------- menu ----------
static void drawCard(Canvas& g, int idx, int xOff) {
  Game* e = entries[idx];
  uint16_t c = e->accent();
  g.fillRoundRect(xOff + 20, 24, 280, 110, 12, pal::PANEL);
  g.drawRoundRect(xOff + 20, 24, 280, 110, 12, c);
  g.drawRoundRect(xOff + 21, 25, 278, 108, 11, c);
  textCentered(g, e->title(), xOff + 160, 44, 3, c);
  if (e->hasScore()) {
    char buf[24];
    snprintf(buf, sizeof buf, "BEST %u", (unsigned)e->best);
    textCentered(g, buf, xOff + 160, 82, 2, pal::WHITE);
  }
  textCentered(g, e->hint(), xOff + 160, 114, 1, pal::DIM);
}

static void drawMenu(Canvas& g) {
  g.fillScreen(pal::BG);
  textLeft(g, "T-EMBED ARCADE", 8, 6, 1, pal::DIM);
  drawCard(g, curSel, (int)slide);
  if (fabsf(slide) > 1.0f) {
    int prevOff = (int)(slide - (slide > 0 ? (float)SCREEN_W : -(float)SCREEN_W));
    drawCard(g, prevSel, prevOff);
  }
  for (int i = 0; i < N; i++) {
    float x = 160 + (i - (N - 1) * 0.5f) * 14;
    g.fillCircle((int)x, 146, i == curSel ? 4 : 2, i == curSel ? pal::WHITE : pal::DIM);
  }
  textCentered(g, "Turn: browse   Press: play   Hold: back", 160, 158, 1, pal::DIM);
}

static void menuTick(float dt, const InputState& in) {
  if (in.delta != 0) {
    prevSel = curSel;
    curSel = wrapi(curSel + in.delta, N);
    slide = (in.delta > 0 ? 1.0f : -1.0f) * SCREEN_W;
  }
  slide -= slide * minf(1.0f, dt * 14.0f);
  if (fabsf(slide) < 1.0f) slide = 0;

  if (in.pressed) {
    active = entries[curSel];
    activeIdx = curSel;
    active->start();
    leds.setMode(Leds::OFF);
  }
}

static void closeGame() {
  if (active && active->bestChanged) saveBest(activeIdx);
  active = nullptr;
  activeIdx = -1;
  leds.setMode(Leds::AMBIENT);
}

// ---------- splash ----------
static void splash() {
  uint32_t t0 = millis();
  while (millis() - t0 < 1400) {
    float k = (millis() - t0) / 1400.0f;
    canvas.fillScreen(pal::BG);
    textCentered(canvas, "ARCADE", 160, 56, 5, pal::CYAN);
    textCentered(canvas, "LilyGO T-Embed CC1101", 160, 108, 1, pal::DIM);
    canvas.fillRoundRect(80, 130, (int)(160 * k), 4, 2, pal::ORANGE);
    leds.tick(0.016f);
    canvas.pushSprite(0, 0);
    delay(16);
  }
}

// ---------- Arduino entry points ----------
void setup() {
  pinMode(pins::PWR_EN, OUTPUT);
  digitalWrite(pins::PWR_EN, HIGH);  // power rail for LEDs, radio, etc.
  pinMode(pins::SD_CS, OUTPUT);
  digitalWrite(pins::SD_CS, HIGH);
  pinMode(pins::RADIO_CS, OUTPUT);
  digitalWrite(pins::RADIO_CS, HIGH);
  delay(50);

  randomSeed(esp_random());

  prefs.begin("arcade", false);
  cfg.flip = prefs.getBool("flip", false);
  cfg.reverse = prefs.getBool("rev", false);
  cfg.led = prefs.getUChar("led", 2);
  for (int i = 0; i < N; i++) {
    char key[8];
    snprintf(key, sizeof key, "b%d", i);
    entries[i]->best = prefs.getUInt(key, 0);
  }

  lcd.init();
  lcd.setRotation(cfg.flip ? 3 : 1);
  lcd.setBrightness(190);
  lcd.fillScreen(0);

  canvas.setColorDepth(16);
  canvas.createSprite(SCREEN_W, SCREEN_H);

  leds.begin(cfg.led);
  inputDev.begin();

  splash();
  lastMicros = micros();
}

void loop() {
  uint32_t t0 = micros();
  float dt = (t0 - lastMicros) / 1000000.0f;
  lastMicros = t0;
  if (dt > 0.05f) dt = 0.05f;

  inputDev.poll();
  const InputState& in = inputDev.state();

  if (active && !active->tick(dt, in)) closeGame();

  if (active) {
    active->draw(canvas);
    if (active->bestChanged) saveBest(activeIdx);
  } else {
    menuTick(dt, in);
    drawMenu(canvas);
  }

  leds.tick(dt);
  canvas.pushSprite(0, 0);

  while (micros() - t0 < 16000) delay(1);
}
