#pragma once
#include <Arduino.h>
#include "ui.h"
#include "input.h"
#include "leds.h"

// Base class: score, best score, game-over screen, "hold to exit" handling.
class Game {
 public:
  virtual ~Game() {}
  virtual const char* title() const = 0;
  virtual const char* hint() const = 0;
  virtual uint16_t accent() const = 0;
  virtual bool hasScore() const { return true; }

  uint32_t best = 0;
  bool bestChanged = false;

  void start() {
    state_ = Playing;
    score_ = 0;
    newBest_ = false;
    overTime_ = 0;
    reset();
  }

  // Returns false when the player wants to go back to the menu.
  virtual bool tick(float dt, const InputState& in) {
    if (in.longPress) return false;
    if (state_ == Over) {
      overTime_ += dt;
      if (in.pressed && overTime_ > 0.6f) start();
      return true;
    }
    step(dt, in);
    return true;
  }

  virtual void draw(Canvas& g) {
    drawWorld(g);
    if (state_ == Over) drawGameOver(g);
  }

 protected:
  enum State { Playing, Over };
  State state_ = Playing;
  uint32_t score_ = 0;
  bool newBest_ = false;
  float overTime_ = 0;

  virtual void reset() = 0;
  virtual void step(float dt, const InputState& in) = 0;
  virtual void drawWorld(Canvas& g) = 0;

  void finish() {
    state_ = Over;
    overTime_ = 0;
    if (score_ > best) {
      best = score_;
      newBest_ = true;
      bestChanged = true;
    }
    leds.flash(255, 30, 30, 600);
  }

  void hud(Canvas& g) {
    g.fillRect(0, 0, SCREEN_W, 13, mk565(14, 18, 34));
    char buf[24];
    snprintf(buf, sizeof buf, "SCORE %u", (unsigned)score_);
    textLeft(g, buf, 4, 3, 1, pal::WHITE);
    uint32_t b = score_ > best ? score_ : best;
    snprintf(buf, sizeof buf, "BEST %u", (unsigned)b);
    textRight(g, buf, SCREEN_W - 4, 3, 1, pal::YELLOW);
  }

  void drawGameOver(Canvas& g) {
    g.fillRoundRect(50, 36, 220, 98, 10, mk565(6, 8, 16));
    g.drawRoundRect(50, 36, 220, 98, 10, accent());
    textCentered(g, "GAME OVER", 160, 44, 3, pal::RED);
    char buf[32];
    snprintf(buf, sizeof buf, "SCORE %u", (unsigned)score_);
    textCentered(g, buf, 160, 76, 2, pal::WHITE);
    if (newBest_) textCentered(g, "NEW BEST!", 160, 96, 2, pal::YELLOW);
    textCentered(g, "Press: retry   Hold: menu", 160, 118, 1, pal::DIM);
  }
};
