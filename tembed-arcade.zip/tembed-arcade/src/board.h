#pragma once
#include <Arduino.h>
#define LGFX_USE_V1
#include <LovyanGFX.hpp>

// LilyGO T-Embed CC1101 pin map
namespace pins {
constexpr int PWR_EN   = 15;  // must be HIGH to power LEDs / radio / etc.
constexpr int SPI_SCK  = 11;
constexpr int SPI_MOSI = 9;
constexpr int TFT_CS   = 41;
constexpr int TFT_DC   = 16;
constexpr int TFT_BL   = 21;
constexpr int SD_CS    = 13;  // kept HIGH (deselected)
constexpr int RADIO_CS = 12;  // CC1101 chip select, kept HIGH (deselected)
constexpr int ENC_A    = 4;
constexpr int ENC_B    = 5;
constexpr int ENC_KEY  = 0;   // knob push button
constexpr int LED_DATA = 14;  // 8x WS2812 ring
}  // namespace pins
constexpr int LED_COUNT = 8;

class LGFX : public lgfx::LGFX_Device {
  lgfx::Panel_ST7789 _panel;
  lgfx::Bus_SPI _bus;
  lgfx::Light_PWM _light;

 public:
  LGFX() {
    {
      auto c = _bus.config();
      c.spi_host = SPI2_HOST;
      c.spi_mode = 0;
      c.freq_write = 40000000;
      c.freq_read = 16000000;
      c.spi_3wire = false;
      c.use_lock = true;
      c.dma_channel = SPI_DMA_CH_AUTO;
      c.pin_sclk = pins::SPI_SCK;
      c.pin_mosi = pins::SPI_MOSI;
      c.pin_miso = -1;
      c.pin_dc = pins::TFT_DC;
      _bus.config(c);
      _panel.setBus(&_bus);
    }
    {
      auto c = _panel.config();
      c.pin_cs = pins::TFT_CS;
      c.pin_rst = -1;
      c.pin_busy = -1;
      c.panel_width = 170;
      c.panel_height = 320;
      c.offset_x = 35;
      c.offset_y = 0;
      c.offset_rotation = 0;
      c.readable = false;
      c.invert = true;
      c.rgb_order = false;
      c.dlen_16bit = false;
      c.bus_shared = false;
      _panel.config(c);
    }
    {
      auto c = _light.config();
      c.pin_bl = pins::TFT_BL;
      c.invert = false;
      c.freq = 44100;
      c.pwm_channel = 7;
      _light.config(c);
      _panel.setLight(&_light);
    }
    setPanel(&_panel);
  }
};
