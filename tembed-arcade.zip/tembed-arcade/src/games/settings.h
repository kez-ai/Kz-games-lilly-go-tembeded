#pragma once
#include "../game.h"

// Not a game: a settings screen that lives in the same menu.
class SettingsScreen : public Game {
 public:
  const char* title() const override { return "SETTINGS"; }
  const char* hint() const override { return "Flip screen, knob, LEDs"; }
  uint16_t accent() const override { return pal::DIM; }
  bool hasScore() const override { return false; }

  bool tick(float dt, const InputState& in) override {
    (void)dt;
    if (in.longPress) return false;
    if (in.delta != 0) {
      sel_ = wrapi(sel_ + in.delta, 4);
      confirm_ = false;
    }
    if (in.pressed) {
      switch (sel_) {
        case 0: cfg.flip = !cfg.flip; applyConfig(); break;
        case 1: cfg.reverse = !cfg.reverse; applyConfig(); break;
        case 2:
          cfg.led = (cfg.led + 1) & 3;
          applyConfig();
          leds.flash(255, 255, 255, 400);
          break;
        case 3:
          if (!confirm_) {
            confirm_ = true;
          } else {
            resetAllScores();
            confirm_ = false;
            leds.flash(60, 255, 120, 400);
          }
          break;
      }
    }
    return true;
  }

 protected:
  int sel_ = 0;
  bool confirm_ = false;

  void reset() override { sel_ = 0; confirm_ = false; }
  void step(float, const InputState&) override {}

  void drawWorld(Canvas& g) override {
    static const char* kLabels[4] = {"Flip screen", "Knob direction", "LED brightness", "Reset high scores"};
    static const char* kLed[4] = {"Off", "Low", "Medium", "High"};
    g.fillScreen(pal::BG);
    textCentered(g, "SETTINGS", 160, 6, 2, pal::CYAN);
    for (int i = 0; i < 4; i++) {
      int y = 32 + i * 28;
      bool s = (i == sel_);
      g.fillRoundRect(10, y, 300, 24, 6, s ? mk565(28, 36, 64) : pal::PANEL);
      if (s) g.drawRoundRect(10, y, 300, 24, 6, pal::CYAN);
      textLeft(g, kLabels[i], 20, y + 4, 2, s ? pal::WHITE : pal::DIM);
      const char* v = "";
      switch (i) {
        case 0: v = cfg.flip ? "Flipped" : "Normal"; break;
        case 1: v = cfg.reverse ? "Reversed" : "Normal"; break;
        case 2: v = kLed[cfg.led & 3]; break;
        case 3: v = confirm_ ? "SURE?" : ""; break;
      }
      textRight(g, v, 300, y + 4, 2, confirm_ && i == 3 ? pal::RED : pal::YELLOW);
    }
    textCentered(g, "Turn: select   Press: change   Hold: back", 160, 154, 1, pal::DIM);
  }
};
