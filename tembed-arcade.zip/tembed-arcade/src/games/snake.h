#pragma once
#include "../game.h"

// Turn the knob clockwise = turn right, counter-clockwise = turn left.
// Edges wrap around.
class SnakeGame : public Game {
 public:
  const char* title() const override { return "SNAKE"; }
  const char* hint() const override { return "Turn = steer left / right"; }
  uint16_t accent() const override { return pal::GREEN; }

 protected:
  enum { GW = 32, GH = 15, CELL = 10, OY = 18, MAXLEN = GW * GH + 4 };

  uint8_t sx_[MAXLEN], sy_[MAXLEN];
  int len_ = 3, dir_ = 1, turnQ_ = 0;
  int fx_ = 0, fy_ = 0;
  float acc_ = 0;

  void reset() override {
    len_ = 3;
    dir_ = 1;
    turnQ_ = 0;
    acc_ = 0;
    for (int i = 0; i < len_; i++) {
      sx_[i] = GW / 2 - i;
      sy_[i] = GH / 2;
    }
    placeFood();
  }

  bool onSnake(int x, int y) const {
    for (int i = 0; i < len_; i++)
      if (sx_[i] == x && sy_[i] == y) return true;
    return false;
  }

  void placeFood() {
    for (int tries = 0; tries < 300; tries++) {
      int x = random(0, GW), y = random(0, GH);
      if (!onSnake(x, y)) { fx_ = x; fy_ = y; return; }
    }
    for (int y = 0; y < GH; y++)
      for (int x = 0; x < GW; x++)
        if (!onSnake(x, y)) { fx_ = x; fy_ = y; return; }
  }

  void moveOnce() {
    static const int dx[4] = {0, 1, 0, -1};
    static const int dy[4] = {-1, 0, 1, 0};
    if (turnQ_ > 0) { dir_ = (dir_ + 1) & 3; turnQ_--; }
    else if (turnQ_ < 0) { dir_ = (dir_ + 3) & 3; turnQ_++; }

    int nx = wrapi(sx_[0] + dx[dir_], GW);
    int ny = wrapi(sy_[0] + dy[dir_], GH);
    bool eat = (nx == fx_ && ny == fy_);

    int checkTo = eat ? len_ : len_ - 1;  // the tail moves away unless we grow
    for (int i = 0; i < checkTo; i++) {
      if (sx_[i] == nx && sy_[i] == ny) { finish(); return; }
    }
    if (eat && len_ < MAXLEN - 1) len_++;
    for (int i = len_ - 1; i > 0; i--) { sx_[i] = sx_[i - 1]; sy_[i] = sy_[i - 1]; }
    sx_[0] = nx;
    sy_[0] = ny;
    if (eat) {
      score_++;
      leds.flash(60, 255, 120, 150);
      placeFood();
    }
  }

  void step(float dt, const InputState& in) override {
    turnQ_ = clampi(turnQ_ + in.delta, -2, 2);
    float interval = maxf(0.055f, 0.14f - score_ * 0.003f);
    acc_ += dt;
    while (acc_ >= interval && state_ == Playing) {
      acc_ -= interval;
      moveOnce();
    }
  }

  void drawWorld(Canvas& g) override {
    g.fillScreen(pal::BG);
    g.drawRect(0, OY - 1, SCREEN_W, GH * CELL + 2, mk565(30, 40, 70));
    for (int i = len_ - 1; i >= 0; i--) {
      uint16_t c = (i == 0) ? mk565(150, 255, 190) : mk565(40, 200, 100);
      g.fillRoundRect(sx_[i] * CELL + 1, OY + sy_[i] * CELL + 1, CELL - 2, CELL - 2, 2, c);
    }
    int r = 3 + ((millis() / 250) & 1);
    g.fillCircle(fx_ * CELL + CELL / 2, OY + fy_ * CELL + CELL / 2, r, pal::RED);
    hud(g);
  }
};
