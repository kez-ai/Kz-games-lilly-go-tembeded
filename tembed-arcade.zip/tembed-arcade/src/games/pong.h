#pragma once
#include "../game.h"

// You (left) vs. the AI (right). Score a point each time you get one past it.
// The AI gets faster as you score. Game ends when it reaches 5.
class PongGame : public Game {
 public:
  const char* title() const override { return "PONG"; }
  const char* hint() const override { return "Turn to move - beat the AI"; }
  uint16_t accent() const override { return pal::CYAN; }

 protected:
  static constexpr float PH = 34.0f, PW = 5.0f, PX = 10.0f, AX = SCREEN_W - 15.0f;
  static constexpr float TOPY = 14.0f, R = 3.0f;
  enum { MAX_MISS = 5 };

  float py_ = 0, ay_ = 0, bx_ = 0, by_ = 0, vx_ = 0, vy_ = 0, speed_ = 150;
  float serveTimer_ = 0;
  int missed_ = 0;

  void reset() override {
    py_ = ay_ = (TOPY + SCREEN_H) / 2;
    missed_ = 0;
    serve(random(0, 2) ? 1 : -1);
  }

  void serve(int dir) {
    speed_ = minf(270.0f, 150.0f + score_ * 6.0f);
    bx_ = SCREEN_W / 2;
    by_ = frand(TOPY + 30, SCREEN_H - 30);
    float a = frand(-0.45f, 0.45f);
    vx_ = dir * speed_ * cosf(a);
    vy_ = speed_ * sinf(a);
    serveTimer_ = 0.8f;
  }

  void step(float dt, const InputState& in) override {
    if (dt > 0.033f) dt = 0.033f;
    float half = PH / 2;
    py_ = clampf(py_ + in.delta * 10.0f, TOPY + half, SCREEN_H - half);

    // AI paddle
    float target = (vx_ > 0 && serveTimer_ <= 0) ? by_ : (TOPY + SCREEN_H) / 2;
    float aiSpeed = minf(190.0f, 75.0f + score_ * 7.0f);
    float diff = target - ay_;
    if (fabsf(diff) > 4) ay_ += clampf(diff, -aiSpeed * dt, aiSpeed * dt);
    ay_ = clampf(ay_, TOPY + half, SCREEN_H - half);

    if (serveTimer_ > 0) { serveTimer_ -= dt; return; }

    bx_ += vx_ * dt;
    by_ += vy_ * dt;
    if (by_ < TOPY + R) { by_ = TOPY + R; vy_ = fabsf(vy_); }
    if (by_ > SCREEN_H - R) { by_ = SCREEN_H - R; vy_ = -fabsf(vy_); }

    // player paddle
    if (vx_ < 0 && bx_ - R <= PX + PW && bx_ + R >= PX && fabsf(by_ - py_) <= half + R) {
      float rel = clampf((by_ - py_) / (half + R), -1.0f, 1.0f);
      speed_ = minf(380.0f, speed_ + 9.0f);
      vx_ = speed_ * cosf(rel);
      vy_ = speed_ * sinf(rel);
      bx_ = PX + PW + R;
    }
    // AI paddle
    if (vx_ > 0 && bx_ + R >= AX && bx_ - R <= AX + PW && fabsf(by_ - ay_) <= half + R) {
      float rel = clampf((by_ - ay_) / (half + R), -1.0f, 1.0f);
      speed_ = minf(380.0f, speed_ + 9.0f);
      vx_ = -speed_ * cosf(rel);
      vy_ = speed_ * sinf(rel);
      bx_ = AX - R;
    }

    if (bx_ < -8) {
      missed_++;
      leds.flash(255, 40, 40, 300);
      if (missed_ >= MAX_MISS) finish();
      else serve(1);
    } else if (bx_ > SCREEN_W + 8) {
      score_++;
      leds.flash(60, 255, 120, 300);
      serve(-1);
    }
  }

  void drawWorld(Canvas& g) override {
    g.fillScreen(pal::BG);
    for (int y = (int)TOPY + 4; y < SCREEN_H; y += 12) g.fillRect(SCREEN_W / 2 - 1, y, 2, 6, mk565(40, 50, 80));
    g.fillRoundRect((int)PX, (int)(py_ - PH / 2), (int)PW, (int)PH, 2, pal::CYAN);
    g.fillRoundRect((int)AX, (int)(ay_ - PH / 2), (int)PW, (int)PH, 2, pal::PINK);
    g.fillCircle((int)bx_, (int)by_, (int)R, pal::WHITE);
    hud(g);
    char buf[16];
    snprintf(buf, sizeof buf, "AI %d/%d", missed_, (int)MAX_MISS);
    textCentered(g, buf, 160, 3, 1, pal::PINK);
  }
};
