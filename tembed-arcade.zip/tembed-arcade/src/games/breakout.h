#pragma once
#include "../game.h"

class BreakoutGame : public Game {
 public:
  const char* title() const override { return "BREAKOUT"; }
  const char* hint() const override { return "Turn to move - press to launch"; }
  uint16_t accent() const override { return pal::ORANGE; }

 protected:
  enum { COLS = 10, ROWS = 5, BW = 30, BH = 9, GAP = 2, TOP = 22 };
  static constexpr float PADDLE_Y = 156.0f;
  static constexpr float PADDLE_H = 5.0f;
  static constexpr float R = 3.0f;

  bool bricks_[ROWS][COLS];
  float px_ = 0, pw_ = 46;
  float bx_ = 0, by_ = 0, vx_ = 0, vy_ = 0, speed_ = 130;
  bool attached_ = true;
  int lives_ = 3, level_ = 1, remaining_ = 0;

  void reset() override {
    lives_ = 3;
    level_ = 1;
    pw_ = 46;
    px_ = (SCREEN_W - pw_) / 2;
    buildLevel();
  }

  void buildLevel() {
    for (int r = 0; r < ROWS; r++)
      for (int c = 0; c < COLS; c++) bricks_[r][c] = true;
    remaining_ = ROWS * COLS;
    speed_ = minf(230.0f, 130.0f + (level_ - 1) * 14.0f);
    attach();
  }

  void attach() {
    attached_ = true;
    bx_ = px_ + pw_ / 2;
    by_ = PADDLE_Y - R - 1;
    vx_ = vy_ = 0;
  }

  // Kills the first brick overlapping a ball centred at (x,y). Returns true on hit.
  bool brickHit(float x, float y) {
    int c0 = (int)((x - R) / (BW + GAP));
    int c1 = (int)((x + R) / (BW + GAP));
    int r0 = (int)((y - R - TOP) / (BH + GAP));
    int r1 = (int)((y + R - TOP) / (BH + GAP));
    c0 = clampi(c0, 0, COLS - 1);
    c1 = clampi(c1, 0, COLS - 1);
    r0 = clampi(r0, 0, ROWS - 1);
    r1 = clampi(r1, 0, ROWS - 1);
    for (int r = r0; r <= r1; r++) {
      for (int c = c0; c <= c1; c++) {
        if (!bricks_[r][c]) continue;
        float bx0 = c * (BW + GAP), by0 = TOP + r * (BH + GAP);
        if (x + R > bx0 && x - R < bx0 + BW && y + R > by0 && y - R < by0 + BH) {
          bricks_[r][c] = false;
          remaining_--;
          score_ += (ROWS - r) * 10;
          speed_ = minf(260.0f, speed_ + 1.5f);
          leds.flash(255, 160, 40, 120);
          return true;
        }
      }
    }
    return false;
  }

  void step(float dt, const InputState& in) override {
    px_ = clampf(px_ + in.delta * 12.0f, 0, SCREEN_W - pw_);
    if (attached_) {
      bx_ = px_ + pw_ / 2;
      if (in.pressed) {
        float a = frand(-0.5f, 0.5f);
        vx_ = speed_ * sinf(a);
        vy_ = -speed_ * cosf(a);
        attached_ = false;
      }
      return;
    }
    if (dt > 0.033f) dt = 0.033f;

    float nx = bx_ + vx_ * dt;
    if (nx < R) { nx = R; vx_ = fabsf(vx_); }
    else if (nx > SCREEN_W - R) { nx = SCREEN_W - R; vx_ = -fabsf(vx_); }
    if (brickHit(nx, by_)) vx_ = -vx_;
    else bx_ = nx;

    float ny = by_ + vy_ * dt;
    if (ny < 14 + R) { ny = 14 + R; vy_ = fabsf(vy_); }
    if (brickHit(bx_, ny)) vy_ = -vy_;
    else by_ = ny;

    if (vy_ > 0 && by_ + R >= PADDLE_Y && by_ - R <= PADDLE_Y + PADDLE_H &&
        bx_ >= px_ - R && bx_ <= px_ + pw_ + R) {
      float rel = clampf((bx_ - (px_ + pw_ / 2)) / (pw_ / 2 + R), -1.0f, 1.0f);
      float a = rel * 1.05f;
      vx_ = speed_ * sinf(a);
      vy_ = -speed_ * cosf(a);
      by_ = PADDLE_Y - R;
    }

    if (by_ > SCREEN_H + 4) {
      lives_--;
      leds.flash(255, 40, 40, 300);
      if (lives_ <= 0) finish();
      else attach();
      return;
    }
    if (remaining_ <= 0) {
      level_++;
      score_ += 50;
      leds.flash(60, 255, 120, 500);
      buildLevel();
    }
  }

  void drawWorld(Canvas& g) override {
    static const uint16_t kRow[ROWS] = {pal::RED, pal::ORANGE, pal::YELLOW, pal::GREEN, pal::BLUE};
    g.fillScreen(pal::BG);
    for (int r = 0; r < ROWS; r++)
      for (int c = 0; c < COLS; c++)
        if (bricks_[r][c]) g.fillRoundRect(c * (BW + GAP), TOP + r * (BH + GAP), BW, BH, 2, kRow[r]);
    g.fillRoundRect((int)px_, (int)PADDLE_Y, (int)pw_, (int)PADDLE_H, 2, pal::WHITE);
    g.fillCircle((int)bx_, (int)by_, (int)R, pal::WHITE);
    hud(g);
    for (int i = 0; i < lives_; i++) g.fillCircle(130 + i * 10, 6, 3, pal::RED);
    char buf[12];
    snprintf(buf, sizeof buf, "LV %d", level_);
    textLeft(g, buf, 190, 3, 1, pal::CYAN);
    if (attached_ && state_ == Playing && ((millis() / 400) & 1))
      textCentered(g, "PRESS TO LAUNCH", 160, 130, 1, pal::DIM);
  }
};
