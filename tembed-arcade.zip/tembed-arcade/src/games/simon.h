#pragma once
#include "../game.h"

// Watch the colour sequence, then repeat it: turn the knob to pick a panel,
// press to confirm. The LED ring flashes in the matching colour.
class SimonGame : public Game {
 public:
  const char* title() const override { return "SIMON"; }
  const char* hint() const override { return "Watch, then repeat - turn & press"; }
  uint16_t accent() const override { return pal::YELLOW; }

 protected:
  enum Phase { PH_PAUSE, PH_SHOW, PH_INPUT, PH_ECHO };
  enum { MAXSEQ = 64 };

  uint8_t seq_[MAXSEQ];
  int len_ = 0, showIdx_ = 0, inputIdx_ = 0, sel_ = 0, lit_ = -1;
  Phase phase_ = PH_PAUSE;
  float timer_ = 0;
  bool on_ = false, correct_ = true;

  void flashLed(int c) {
    static const uint8_t kRGB[4][3] = {{255, 40, 40}, {40, 255, 80}, {50, 110, 255}, {255, 200, 40}};
    leds.flash(kRGB[c][0], kRGB[c][1], kRGB[c][2], on_ ? 350 : 220);
  }

  void addStep() {
    if (len_ < MAXSEQ) seq_[len_++] = (uint8_t)random(0, 4);
  }

  void reset() override {
    len_ = 0;
    addStep();
    phase_ = PH_PAUSE;
    timer_ = 0.8f;
    lit_ = -1;
    sel_ = 0;
    on_ = false;
  }

  void step(float dt, const InputState& in) override {
    timer_ -= dt;
    switch (phase_) {
      case PH_PAUSE:
        if (timer_ <= 0) {
          phase_ = PH_SHOW;
          showIdx_ = 0;
          on_ = false;
          lit_ = -1;
          timer_ = 0.15f;
        }
        break;

      case PH_SHOW:
        if (timer_ <= 0) {
          if (!on_) {
            if (showIdx_ >= len_) {
              phase_ = PH_INPUT;
              inputIdx_ = 0;
              lit_ = -1;
              break;
            }
            lit_ = seq_[showIdx_];
            on_ = true;
            timer_ = maxf(0.18f, 0.5f - len_ * 0.015f);
            flashLed(lit_);
          } else {
            on_ = false;
            lit_ = -1;
            showIdx_++;
            timer_ = 0.15f;
          }
        }
        break;

      case PH_INPUT:
        sel_ = wrapi(sel_ + in.delta, 4);
        if (in.pressed) {
          lit_ = sel_;
          correct_ = (sel_ == seq_[inputIdx_]);
          if (correct_) inputIdx_++;
          on_ = false;
          flashLed(lit_);
          timer_ = 0.22f;
          phase_ = PH_ECHO;
        }
        break;

      case PH_ECHO:
        if (timer_ <= 0) {
          lit_ = -1;
          if (!correct_) {
            finish();
          } else if (inputIdx_ >= len_) {
            score_ = len_;
            if (len_ >= MAXSEQ) { finish(); break; }
            addStep();
            phase_ = PH_PAUSE;
            timer_ = 0.7f;
          } else {
            phase_ = PH_INPUT;
          }
        }
        break;
    }
  }

  void drawWorld(Canvas& g) override {
    static const uint16_t kBright[4] = {mk565(255, 70, 80), mk565(60, 230, 120), mk565(70, 140, 255), mk565(255, 210, 60)};
    static const uint16_t kDark[4] = {mk565(70, 20, 25), mk565(15, 65, 35), mk565(20, 40, 75), mk565(75, 60, 15)};
    static const int kX[4] = {9, 161, 161, 9};
    static const int kY[4] = {20, 20, 94, 94};
    g.fillScreen(pal::BG);
    for (int i = 0; i < 4; i++)
      g.fillRoundRect(kX[i], kY[i], 150, 68, 10, lit_ == i ? kBright[i] : kDark[i]);
    if (state_ == Playing && (phase_ == PH_INPUT || phase_ == PH_ECHO)) {
      g.drawRoundRect(kX[sel_], kY[sel_], 150, 68, 10, pal::WHITE);
      g.drawRoundRect(kX[sel_] + 1, kY[sel_] + 1, 148, 66, 9, pal::WHITE);
    }
    hud(g);
    if (state_ == Playing)
      textCentered(g, (phase_ == PH_INPUT || phase_ == PH_ECHO) ? "YOUR TURN" : "WATCH", 160, 3, 1, pal::CYAN);
  }
};
