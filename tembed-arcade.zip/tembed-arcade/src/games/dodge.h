#pragma once
#include "../game.h"

// Slide your ship left/right and dodge the falling rocks. Score = time survived.
class DodgeGame : public Game {
 public:
  const char* title() const override { return "DODGE"; }
  const char* hint() const override { return "Turn to slide - survive"; }
  uint16_t accent() const override { return pal::PURPLE; }

 protected:
  struct Rock { float x, y, w, h, vy; uint16_t c; bool on; };
  enum { NROCKS = 24, NSTARS = 32 };
  static constexpr float SHIP_Y = 146.0f;

  Rock rocks_[NROCKS];
  float starX_[NSTARS], starY_[NSTARS], starV_[NSTARS];
  float x_ = 160, t_ = 0, spawn_ = 0.5f;

  void reset() override {
    x_ = SCREEN_W / 2;
    t_ = 0;
    spawn_ = 0.5f;
    for (int i = 0; i < NROCKS; i++) rocks_[i].on = false;
    for (int i = 0; i < NSTARS; i++) {
      starX_[i] = frand(0, SCREEN_W);
      starY_[i] = frand(0, SCREEN_H);
      starV_[i] = frand(15, 60);
    }
  }

  void spawnRock() {
    static const uint16_t kCols[4] = {pal::ORANGE, pal::PINK, pal::PURPLE, pal::YELLOW};
    for (int i = 0; i < NROCKS; i++) {
      if (rocks_[i].on) continue;
      Rock& r = rocks_[i];
      r.w = frand(10, 30);
      r.h = frand(8, 16);
      r.x = frand(r.w / 2, SCREEN_W - r.w / 2);
      r.y = -10;
      r.vy = minf(240.0f, 70.0f + t_ * 2.2f + frand(0, 50));
      r.c = kCols[random(0, 4)];
      r.on = true;
      return;
    }
  }

  void step(float dt, const InputState& in) override {
    if (dt > 0.05f) dt = 0.05f;
    x_ = clampf(x_ + in.delta * 16.0f, 8, SCREEN_W - 8);
    t_ += dt;
    score_ = (uint32_t)(t_ * 10.0f);

    spawn_ -= dt;
    if (spawn_ <= 0) {
      spawn_ = maxf(0.2f, 0.65f - t_ * 0.008f);
      spawnRock();
    }
    for (int i = 0; i < NSTARS; i++) {
      starY_[i] += starV_[i] * dt;
      if (starY_[i] > SCREEN_H) { starY_[i] = 0; starX_[i] = frand(0, SCREEN_W); }
    }
    for (int i = 0; i < NROCKS; i++) {
      Rock& r = rocks_[i];
      if (!r.on) continue;
      r.y += r.vy * dt;
      if (r.y > SCREEN_H + 20) { r.on = false; continue; }
      if (fabsf(r.x - x_) < r.w / 2 + 6 && fabsf(r.y - SHIP_Y) < r.h / 2 + 7) {
        finish();
        return;
      }
    }
  }

  void drawWorld(Canvas& g) override {
    g.fillScreen(pal::BG);
    for (int i = 0; i < NSTARS; i++) g.drawPixel((int)starX_[i], (int)starY_[i], mk565(90, 100, 140));
    for (int i = 0; i < NROCKS; i++) {
      const Rock& r = rocks_[i];
      if (r.on) g.fillRoundRect((int)(r.x - r.w / 2), (int)(r.y - r.h / 2), (int)r.w, (int)r.h, 3, r.c);
    }
    int x = (int)x_, y = (int)SHIP_Y;
    g.fillTriangle(x, y - 8, x - 7, y + 7, x + 7, y + 7, pal::WHITE);
    if ((millis() / 90) & 1) g.fillTriangle(x - 3, y + 8, x + 3, y + 8, x, y + 14, pal::ORANGE);
    hud(g);
  }
};
