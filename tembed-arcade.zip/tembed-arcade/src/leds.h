#pragma once
#include <Arduino.h>
#include <Adafruit_NeoPixel.h>
#include "board.h"

// The 8-LED ring around the knob.
class Leds {
 public:
  enum Mode { OFF, AMBIENT };

  Leds() : strip_(LED_COUNT, pins::LED_DATA, NEO_GRB + NEO_KHZ800) {}

  void begin(int level) {
    strip_.begin();
    setLevel(level);
    strip_.clear();
    strip_.show();
  }

  void setLevel(int level) {
    static const uint8_t kLevels[4] = {0, 10, 35, 90};
    strip_.setBrightness(kLevels[clampLevel(level)]);
  }

  void setMode(Mode m) { mode_ = m; }

  // Light the whole ring for `ms`, fading out.
  void flash(uint8_t r, uint8_t g, uint8_t b, uint16_t ms) {
    fr_ = r; fg_ = g; fb_ = b;
    flashLen_ = ms;
    flashUntil_ = millis() + ms;
  }

  void tick(float dt) {
    uint32_t now = millis();
    if ((int32_t)(flashUntil_ - now) > 0) {
      float k = (float)(flashUntil_ - now) / (float)flashLen_;
      uint32_t c = strip_.Color((uint8_t)(fr_ * k), (uint8_t)(fg_ * k), (uint8_t)(fb_ * k));
      for (int i = 0; i < LED_COUNT; i++) strip_.setPixelColor(i, c);
      strip_.show();
      lit_ = true;
      return;
    }
    if (mode_ == AMBIENT) {
      phase_ += dt * 3500.0f;
      if (phase_ >= 65536.0f) phase_ -= 65536.0f;
      for (int i = 0; i < LED_COUNT; i++) {
        uint16_t hue = (uint16_t)((uint32_t)phase_ + (uint32_t)i * 8192u);
        strip_.setPixelColor(i, strip_.gamma32(strip_.ColorHSV(hue, 255, 255)));
      }
      strip_.show();
      lit_ = true;
    } else if (lit_) {
      strip_.clear();
      strip_.show();
      lit_ = false;
    }
  }

 private:
  static int clampLevel(int l) { return l < 0 ? 0 : (l > 3 ? 3 : l); }

  Adafruit_NeoPixel strip_;
  Mode mode_ = AMBIENT;
  uint32_t flashUntil_ = 0;
  uint16_t flashLen_ = 1;
  uint8_t fr_ = 0, fg_ = 0, fb_ = 0;
  float phase_ = 0;
  bool lit_ = false;
};

static Leds leds;
