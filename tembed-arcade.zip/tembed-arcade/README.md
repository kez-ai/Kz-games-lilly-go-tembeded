# T-Embed Arcade (LilyGO T-Embed CC1101)

Five games + a settings screen, all driven by the knob and the LED ring.

| Game | Controls |
|------|----------|
| Breakout | Turn = paddle, press = launch ball |
| Pong | Turn = paddle, first to 5 misses loses to the AI |
| Snake | Turn clockwise = right, counter-clockwise = left (edges wrap) |
| Dodge | Turn = slide ship, dodge rocks, score = time survived |
| Simon | Watch the sequence, turn to pick a panel, press to confirm |

Everywhere: **hold the knob (0.6 s) to go back to the menu.** High scores are saved.

Screen upside down or knob backwards? Open **Settings** in the menu: flip screen,
reverse knob, LED brightness, reset scores. No rebuild needed.

## Get it onto the device (no local setup)

1. Create a GitHub repo and upload this whole folder (including `.github`).
2. Open the **Actions** tab -> latest "Build firmware" run -> download the **tembed-arcade** artifact.
3. Unzip it. Flash `tembed-arcade-full.bin` at address **0x0** with a web flasher
   (e.g. https://esp.huhn.me in Chrome/Edge).
   To enter download mode: hold the knob while plugging in USB-C, then release.

## Or build locally

```
pio run -t upload
```
